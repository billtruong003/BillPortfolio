Bill The Dev - Toon shader for Unity 6 URP
https://www.billthedev.com/lab/shader-toon-urp

Copy the BillShaderLab folder into Assets. The .meta files keep the import settings
(ramps: Clamp, no mipmaps; prototype grids: Repeat) and link the materials to their textures.

Shaders/Toon           Bill/Toon, the finished shader
Shaders/Common         ShadowCaster, DepthOnly and DepthNormals passes
Shaders/Tutorial/Toon  one shader per step of the article (01 Unlit .. 09b Outline Smooth Normals)
Editor                 SmoothNormalBaker, bakes outline normals into UV3
Textures/Ramps         three ramp textures
Textures/Prototype     the grid textures used on the showcase map
Materials              Toon_Studio (the sphere) and the prototype materials

Unity primitives (Sphere, Cube) have no UV3: bake smooth normals on a copy of the mesh
or the outline falls back to the mesh normals.
