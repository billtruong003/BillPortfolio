Bill The Dev - Stylized water for Unity 6 URP
https://www.billthedev.com/lab/shader-stylized-water-urp

Copy the BillShaderLab folder into Assets. Enable Depth Texture and Opaque Texture on the
URP asset or on the camera. The .meta files keep the import settings (noise: single channel,
not sRGB; ripples: normal map from grayscale) and link the material to its textures.

Shaders/Water           Bill/StylizedWater, the finished shader (Gerstner waves behind _WAVES)
Shaders/Tutorial/Water  one shader per step of the article (01 Flat .. 09 Specular)
Textures/Normals        two ripple normal maps made from SBS Perlin tiles
Textures/SBS            SuperPerlin_03 (surface foam), SuperPerlin_09 (shore foam)
Materials               StylizedWater, the values used in the article

The water mesh must be dense for the waves: the showcase uses a 36 m grid with 240 cells per side.

Noise textures: SBS Noise Texture Pack by Screaming Brain Studios, CC0.
https://screamingbrainstudios.itch.io/noise-texture-pack
