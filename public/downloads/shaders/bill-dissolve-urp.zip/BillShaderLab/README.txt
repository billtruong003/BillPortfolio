Bill The Dev - Dissolve shader for Unity 6 URP
https://www.billthedev.com/lab/shader-dissolve-urp

Copy the BillShaderLab folder into Assets. Needs a Bloom override (threshold about 1) in a
Volume for the edge to glow. The dissolve reuses ToonLighting from the toon shader, so the
Toon folder is part of this package.

Shaders/Dissolve           Bill/Dissolve, the finished shader (shapes and vertex motion are keywords),
                           BillTransition.hlsl (Global shape) and Bill/XRay
Shaders/Toon               Bill/Toon, whose lighting the dissolve calls
Shaders/Common             shadow and depth passes used by the tutorial steps
Shaders/Tutorial/Dissolve  one shader per step of the article (01 UV Noise .. 06 Inside)
Scripts                    PropertyPingPong (drives _DissolveAmount for testing), DissolveShape (part 2),
                           TransitionShape + TransitionMask (part 4), ShapePulse, PathPingPong
Textures/SBS               Perlin_02 (dissolve noise) with the SBS licence
Textures/Ramps             ramp used by the toon lighting
Materials                  Dissolve_Demo, Global_Dark (cut inside), GlobalKeep_Light (keep inside),
                           XRay_Burrow (add as a second material on a character)

Perlin_02 only covers about 0.36..0.64 after the triplanar blend: that is what Noise Range
on the material stretches back to 0..1. Measure again if you swap the noise.

Noise textures: SBS Noise Texture Pack by Screaming Brain Studios, CC0.
https://screamingbrainstudios.itch.io/noise-texture-pack
